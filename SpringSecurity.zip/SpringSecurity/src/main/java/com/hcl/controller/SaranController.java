package com.hcl.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SaranController {

	@GetMapping("/")
	public String display() {
		return "<h1 style=color:blue><marquee behavior=alternate>"
				+ "Welcome to the world of Spring Security</marquee></h1>";
	}

	@GetMapping("/admin")
	public String admin() {
		return "Welcome Admin";
	}

	@GetMapping("/user")
	public String user() {
		return "Welcome User";
	}

}
