package com.hcl.controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.annotations.ApiOperation;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Arrays;
import java.util.List;

@RestController
@RequestMapping("/api/user")
@Api(value = "User Resource REST Endpoint", description = "Shows the user info")
public class UserController {

    @GetMapping
    @ApiOperation(value="Find List of Users",notes="used to retreive list of users",response=User.class)
    public List<User> getUsers() {

        return Arrays.asList(
                new User("Phisa", 2000L),
                new User("Rafee", 1000L)
        );
    }

    @GetMapping("/{userName}")
    public User getUser(@PathVariable("userName") final String userName)
    {
        return new User(userName, 1000L);
    }


    private class User {

        @ApiModelProperty(notes = "name of the User")
        private String userName;

        @ApiModelProperty(notes = "salary of the user")
        private Long salary;

        public User(String userName, Long salary) {
            this.userName = userName;
            this.salary = salary;
        }

        public String getUserName() {
            return userName;
        }

        public void setUserName(String userName) {
            this.userName = userName;
        }

        public Long getSalary() {
            return salary;
        }

        public void setSalary(Long salary) {
            this.salary = salary;
        }
    }
}